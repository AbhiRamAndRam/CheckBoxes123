//
//  StaticServerVC.m
//  BarCodeSampleApp
//
//  Created by Venkat on 2/14/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import "StaticServerVC.h"

@implementation StaticServerVC

@end
