//
//  BacGroundGetMethodServiceClass.h
//  BarCodeSampleApp
//
//  Created by Venkat on 12/9/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StaticServerVC.h"

@protocol GetServiceprotocol<NSObject>

@required
- (void) GetCallService1: (id)MainResponse;
- (void) BsicEroor :(NSString*)ErrorString;
@end

@interface BacGroundGetMethodServiceClass : UIViewController

-(void)getServieCalling :(NSString*)mainurl;

@property (nonatomic, strong) id<GetServiceprotocol> delegate;

@end
