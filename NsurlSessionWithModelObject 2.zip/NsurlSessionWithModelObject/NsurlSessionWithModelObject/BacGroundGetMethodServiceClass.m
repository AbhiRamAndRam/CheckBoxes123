//
//  BacGroundGetMethodServiceClass.m
//  BarCodeSampleApp
//
//  Created by Venkat on 12/9/15.
//  Copyright (c) 2015 Ensis. All rights reserved.


#import "BacGroundGetMethodServiceClass.h"

@interface BacGroundGetMethodServiceClass (){
    
    int mainServiceCallingNo;
}

@end

@implementation BacGroundGetMethodServiceClass
@synthesize delegate;

- (void)viewDidLoad {
    [super viewDidLoad];
}

-(void)getServieCalling :(NSString*)mainurl{
    
    // [ProgressIndicator showGlobalProgressHUDWithTitle];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:mainurl,kServerBaseURL1]]
                                    
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                    
                                                       timeoutInterval:60.0];
    
    [request setHTTPMethod:@"GET"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        if (error != nil) {
            
            NSString * BasicnetworkError = [error localizedDescription];
            NSString * AppendString = @"Http Response failed with the following ";
            NSString * networkError = [AppendString stringByAppendingString:BasicnetworkError];
            
            [self BasicError:networkError];
            
            return;
        }
        
        else if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            if (statusCode != 200) {
                
                NSString *statusCodeError = [NSString stringWithFormat: @"Http Response failed with the following code %ld", (long)statusCode];
                
                [self BasicError:statusCodeError];
                
            }else{
                
                NSError *parseError;
                
                id responseObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
                
                NSLog(@"response object %@",responseObject);
                
                if (responseObject) {
                    
                    [self MainService1:responseObject];
                }
                
                else {
                    
                    NSLog(@"Error parsing JSON: %@", parseError);
                    
                    NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                    
                    NSLog(@"responseString = %@", responseString);
                }
            }
        }
        
    }];
    
    [task resume];
}

-(void)MainService1 :(id)MainResponse{
    // [ProgressIndicator dismissGlobalHUD];
    
    [delegate GetCallService1 :MainResponse];
}

-(void)BasicError:(NSString*)BasicErrotrString{
    // [ProgressIndicator dismissGlobalHUD];
    [delegate BsicEroor:BasicErrotrString];
}

@end
