//
//  ModelObject1.h
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 4/4/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ModelObject1 : NSObject{
    
    NSString *MasterId;
    NSString *Name;
    BOOL  ischeck;
}
@property(nonatomic, retain) NSString *MasterId;
@property(nonatomic, retain) NSString *Name;
@property(nonatomic) BOOL ischeck;

-(void)loadingservices :(id)mainDictionary;

@end
