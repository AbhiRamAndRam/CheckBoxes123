//
//  ViewController.m
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 4/4/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    
    BacGroundGetMethodServiceClass * get;
    ModelObject1 * model1;
    NSString * alertmessage;
    UITableView * MaintableView;
    NSMutableArray * mainArray,*checkBoxesArray;
    UIButton *newBtn;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    mainArray = [[NSMutableArray alloc]init];
    checkBoxesArray = [[NSMutableArray alloc]init];
    
    get = [[BacGroundGetMethodServiceClass alloc]init];
    get.delegate = self;
    
    [get getServieCalling:@"%@common/GetMasterData?entity=COLORS"];
}

- (void) GetCallService1: (id)MainResponse{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if ([MainResponse isKindOfClass:[NSDictionary class]] && MainResponse[@"error"]){
            
            alertmessage = [MainResponse objectForKey:@"message"];
            [self ShowingAlertMesaage:alertmessage];
            
        }else if ([MainResponse count] == 0){
            
            [self ShowingAlertMesaage:@"Server not responding please try again"];
        }
        else{
            
             NSArray * array = MainResponse;
            //NSArray * array = [MainResponse objectForKey:@"Batches"];
            
            for(int i = 0; i <array.count; i++){
                
                model1 = [[ModelObject1 alloc]init];
                [model1 loadingservices :array[i]];
                [mainArray addObject:model1];
                [checkBoxesArray addObject:@""];
            }
        
            [self createTableList];
         }
    });
}

-(void)BsicEroor:(NSString *)ErrorString{
    
}

-(void)ShowingAlertMesaage :(NSString*)AlertMessage{
    
    OpinionzAlertView *alert = [[OpinionzAlertView alloc] initWithTitle:@"Alert!!"
                                                                message:AlertMessage
                                                      cancelButtonTitle:@"OK"
                                                      otherButtonTitles:nil];
    alert.iconType = OpinionzAlertIconSuccess;
    alert.delegate = self;
    alert.color = [UIColor colorWithRed:0.15 green:0.68 blue:0.38 alpha:1];
    
    [alert show];
}

//Crating TableList :-

-(void)createTableList{
    
    //Create UITableList:-
    [MaintableView removeFromSuperview];
    MaintableView = [[UITableView alloc] initWithFrame:CGRectMake(5, 118, self.view.frame.size.width-10, self.view.frame.size.height-75)  style:UITableViewStylePlain];
    MaintableView.delegate = self;
    MaintableView.dataSource = self;
    MaintableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    MaintableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    MaintableView.contentInset = UIEdgeInsetsMake(0, 0, 75, 0);
    MaintableView.bounces = NO;
    [self.view addSubview:MaintableView];
}

//TableList Delegate Methods:-

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return mainArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"HistoryCell";
    
    UITableViewCell *cell = (UITableViewCell *)[MaintableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil){
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];

    }
    
    model1 = mainArray[indexPath.row];
    cell.textLabel.text = model1.Name;
    cell.detailTextLabel.text = model1.MasterId;
    
    bool variable = checkBoxesArray[indexPath.row];
    
    newBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [newBtn setFrame:CGRectMake(250,5,30,30)];
    [newBtn addTarget:self action:@selector(urSelctor:) forControlEvents:UIControlEventTouchUpInside];
    
    UIImage *btnImage;
    if(variable == YES){
        NSLog(@"1");
        btnImage = [UIImage imageNamed:@"check.png"];
    }else{
        NSLog(@"2");
        btnImage = [UIImage imageNamed:@"uncheck.png"];
    }
    [newBtn setImage:btnImage forState:UIControlStateNormal];
    
    [cell addSubview:newBtn];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    ViewController1 *controller = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController1"];
    //ModelObject1 *model = mainArray[indexPath.row];
    model1 = mainArray[indexPath.row];
    controller.modelobj = model1;
    controller.modelobjArray = mainArray;
    [self.navigationController pushViewController:controller animated:YES];
}

-(void)urSelctor :(UIButton*)sender{
    
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:MaintableView];
    NSIndexPath *indexPath1 = [MaintableView indexPathForRowAtPoint:buttonPosition];
    NSInteger variable = indexPath1.row;
    
    bool variablePosition = checkBoxesArray[variable];
    
    if (variablePosition == YES){
        variablePosition= NO;
        [checkBoxesArray replaceObjectAtIndex:variable withObject:[NSString stringWithFormat:@"%d",variablePosition]];
    }
    else{
        variablePosition = YES;
        [checkBoxesArray replaceObjectAtIndex:variable withObject:[NSString stringWithFormat:@"%d",variablePosition]];
    }

    [MaintableView reloadData];
}

@end
