//
//  ModelObject1.m
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 4/4/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ModelObject1.h"

@implementation ModelObject1

@synthesize MasterId,Name,ischeck;

-(void)loadingservices :(id)mainDictionary{
    
    Name = [mainDictionary objectForKey:@"Name"];
    MasterId = [mainDictionary objectForKey:@"MasterId"];
}

@end
