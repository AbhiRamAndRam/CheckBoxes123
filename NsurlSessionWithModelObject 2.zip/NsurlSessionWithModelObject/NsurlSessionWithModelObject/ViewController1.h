//
//  ViewController1.h
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 6/13/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ModelObject1.h"

@interface ViewController1 : UIViewController

@property (strong,nonatomic)NSMutableArray *modelobjArray;
@property (strong,nonatomic)ModelObject1 *modelobj;

@end
