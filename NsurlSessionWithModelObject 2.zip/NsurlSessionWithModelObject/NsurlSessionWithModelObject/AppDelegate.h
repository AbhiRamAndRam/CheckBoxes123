//
//  AppDelegate.h
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 4/4/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

