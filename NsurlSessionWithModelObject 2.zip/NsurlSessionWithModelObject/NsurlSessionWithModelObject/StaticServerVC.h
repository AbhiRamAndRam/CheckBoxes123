//
//  StaticServerVC.h
//  BarCodeSampleApp
//
//  Created by Venkat on 2/14/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import <Foundation/Foundation.h>

#define kServerBaseURL @"http://203.77.214.78:80/stockmanager/"
#define kServerBaseURL1 @"http://203.77.209.194/SerbaAntik/"

@interface StaticServerVC : NSObject

@end
