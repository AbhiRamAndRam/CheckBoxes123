//
//  ViewController1.m
//  NsurlSessionWithModelObject
//
//  Created by Venkat on 6/13/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ViewController1.h"

@interface ViewController1 ()

@end

@implementation ViewController1
@synthesize modelobj,modelobjArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    for (int i=0; i<modelobjArray.count;++i) {
        
        modelobj = modelobjArray[i];
        NSLog(@"Name is=======>%@",modelobj.Name);
        NSLog(@"Check value is%hhd",modelobj.ischeck);
    }
 }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
